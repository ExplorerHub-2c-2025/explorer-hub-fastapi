// Hook personalizado para autenticación
export { useAuthRequired } from "./use-auth-required"
