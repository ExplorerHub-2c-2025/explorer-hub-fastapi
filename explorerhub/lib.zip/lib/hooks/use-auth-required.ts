"use client"

import { useState, useCallback, useEffect } from "react"
import { isAuthenticated } from "@/lib/auth"

/**
 * Hook personalizado para manejar acciones que requieren autenticación
 * @returns objeto con funciones y estado para manejar autenticación
 */
export function useAuthRequired() {
  const [showAuthDialog, setShowAuthDialog] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const authenticated = isAuthenticated()
    setIsLoggedIn(authenticated)
    console.log("useAuthRequired - Usuario autenticado:", authenticated)
  }, [])

  /**
   * Ejecuta una acción solo si el usuario está autenticado
   * Si no está autenticado, muestra el diálogo de autenticación
   * @param action - Función a ejecutar si el usuario está autenticado
   */
  const requireAuth = useCallback(
    (action: () => void) => {
      console.log("requireAuth - isLoggedIn:", isLoggedIn)
      if (isLoggedIn) {
        action()
      } else {
        console.log("requireAuth - Mostrando diálogo de autenticación")
        setShowAuthDialog(true)
      }
    },
    [isLoggedIn]
  )

  useEffect(() => {
    console.log("showAuthDialog cambió a:", showAuthDialog)
  }, [showAuthDialog])

  return {
    showAuthDialog,
    setShowAuthDialog,
    isLoggedIn,
    requireAuth,
  }
}
